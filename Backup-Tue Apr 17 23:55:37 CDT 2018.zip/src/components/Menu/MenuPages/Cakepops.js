import React, {Component} from 'react';

class Cakepops extends Component {
    render() {
        return (
            <div>Cakepops</divCakepops>
        );
    }
}

export default Cakepops;
