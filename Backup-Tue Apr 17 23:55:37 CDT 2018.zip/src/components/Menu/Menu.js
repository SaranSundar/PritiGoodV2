import React, {Component} from 'react';
import "./Menu.css"
import {NavLink, Route, Switch} from "react-router-dom";
import MenuLanding from "./MenuPages/MenuLanding";
import Cakepops from "./MenuPages/Cakepops";

class Menu extends Component {
    render() {
        return (
            <div className="Menu">
                <div className="mainMenu">
                    <h1>MENU</h1>
                </div>
                <ul className="menuItems">
                    <NavLink activeClassName={"selected"} exact={true} to="/Menu/Desserts">
                        <div className="centerDivs">
                            <img className="cakeImage" src="img/Cake.png"/>
                            <li>Desserts</li>
                        </div>
                    </NavLink>
                    <NavLink activeClassName={"selected"} exact={true} to="/Menu/CakePops">
                        <div className="centerDivs">
                            <img className="cupcakeImage" src="img/Cupcake.png"/>
                            <li>Cake Pops</li>
                        </div>
                    </NavLink>
                    <NavLink activeClassName={"selected"} exact={true} to="/Menu/Cookies">
                        <div className="centerDivs">
                            <img className="cookieImage" src="img/Cookies.png"/>
                            <li>Cookies</li>
                        </div>
                    </NavLink>
                    <NavLink activeClassName={"selected"} exact={true} to="/Menu/Cupcakes">
                        <div className="centerDivs">
                            <img className="cupcakeImage" src="img/Cupcake.png"/>
                            <li>Cupcakes</li>
                        </div>
                    </NavLink>
                </ul>
                <Switch>
                    <Route path="/menu" component={MenuLanding}/>
                    <Route path="/menu/cakepops" component={Cakepops}/>
                </Switch>
            </div>
        );
    }
}

export default Menu;
