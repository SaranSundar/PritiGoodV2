import React, {Component} from 'react';
import "./Menu.css"
import {NavLink} from "react-router-dom";

class Menu extends Component {
    render() {
        return (
            <div className="Menu">
                <div className="mainMenu">
                    <h1>MENU</h1>
                </div>
                <ul className="menuItems">
                    <NavLink activeClassName={"selected"} exact={true} to="/Menu/Cakes">
                        <div className="centerDivs">
                            <img className="cakeImage" src="img/Cake.png"/>
                            <li>Cakes</li>
                        </div>
                    </NavLink>
                    <NavLink activeClassName={"selected"} exact={true} to="/Menu/CakePops">
                        <div className="centerDivs">
                            <img className="cupcakeImage" src="img/Cupcake.png"/>
                            <li>Cake Pops</li>
                        </div>
                    </NavLink>
                    <NavLink activeClassName={"selected"} exact={true} to="/Menu/Cookies">
                        <div className="centerDivs">
                            <img className="cookieImage" src="img/Cookies.png"/>
                            <li>Cookies</li>
                        </div>
                    </NavLink>
                    <NavLink activeClassName={"selected"} exact={true} to="/Menu/Cupcakes">
                        <div className="centerDivs">
                            <img className="cupcakeImage" src="img/Cupcake.png"/>
                            <li>Cupcakes</li>
                        </div>
                    </NavLink>
                </ul>
                <div className="containerMenu">
                    <div className="item">
                        <img src="img/WhiteCake.jpg"/>
                        <div className="item__overlay colorWhite">
                            <span>DESSERTS</span>
                            <button>VIEW DESSERTS</button>
                        </div>
                    </div>
                    <div className="item">
                        <img src="img/CakepopPink.jpeg"/>
                        <div className="item__overlay colorPink">
                            <span>CAKE POPS</span>
                            <button>VIEW CAKE POPS</button>
                        </div>
                    </div>
                    <div className="item">
                        <img src="img/Cookie.jpg"/>
                        <div className="item__overlay colorTurquoise">
                            <span>COOKIES</span>
                            <button>VIEW COOKIES</button>
                        </div>
                    </div>

                </div>
            </div>
        );
    }
}

export default Menu;
