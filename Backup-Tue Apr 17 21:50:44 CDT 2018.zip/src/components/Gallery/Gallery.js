import React, {Component} from 'react';
import "./Gallery.css"

class GridObject {
    constructor(w, h, canPartition) {
        this.width = w;
        this.height = h;
        this.canPartition = canPartition;
    }

    setCanPartition(canPartition) {
        this.canPartition = canPartition;
    }

    getCanPartition() {
        return this.canPartition;
    }

    getWidth() {
        return this.width;
    }

    getHeight() {
        return this.height;
    }
}

class Gallery extends Component {

    constructor(props) {
        super(props);
        this.state = {
            gridItems: null
        }
    }


    /** This JavaScript function always returns a
     * random number between min (included) and max (excluded) **/
    static getRndInteger(min, max) {
        return Math.floor(Math.random() * (max - min)) + min;
    }

    componentDidMount() {
        let partitions = [].concat([[1, 1]]); // Maybe [4,4],[1,4],[4,1],[2,2]
        // numImages, gridWidth, gridHeight, partitionsArray
        //let grid = Gallery.createGrid(12, 11, 4, partitions);
        let grid = [].concat([[1,3]],[[1,3]],[[4,3]],[[1,3]],[[4,3]],[[2,1]],[[1,1]],[[4,1]],[[4,1]],[[2,4]],[[5,4]],[[4,4]]);
        console.log(grid);
        let gridItems = grid.map((item) =>
            <div className={"Gallery-item"} style={{gridColumn: "span " + item[0], gridRow: "span " + item[1]}}>
                <img src={"img/" + Gallery.getRndInteger(1,13) + ".jpg"}/>
            </div>
        );
        this.setState({gridItems: gridItems});
    }

    /***
     * ALL MATH DONE IN INTEGERS
     * @param numImages is the amount of partitions needed
     * @param gridWidth is the number of col span
     * @param gridHeight is the number of row span
     * @param partitionsArray is the finalized block sizes that cant be divided anymore
     */
    static createGrid(numImages, gridWidth, gridHeight, partitionsArray) {
        let grid = [].concat(new GridObject(gridWidth, gridHeight, true));
        let partitions = 1;
        let numPartionableBlocks = 1;
        // MAKE SURE YOU ADD MORE TO NUM PARTITIONABLE BLOCKS
        // AND FIGURE OUT HOW TO ADD BLOCKS IF YOU RUN OUT OF PARTIONABLE BLOCKS
        while (partitions < numImages && numPartionableBlocks <= partitions) {
            let index = Gallery.getRndInteger(0, grid.length);
            let block = grid[index];
            if (block.getCanPartition()) {
                let widthOrHeight = Gallery.getRndInteger(0, 100) < 50 ? "width" : "height";
                let blockRemoved = grid[index];
                grid.splice(index, 1);
                let widthTemp = 0;
                let heightTemp = 0;
                let canPartition1 = true;
                let canPartition2 = true;
                let block1 = null;
                let block2 = null;
                if (blockRemoved.getWidth() === 1) {
                    widthOrHeight = "width";
                }
                else if (blockRemoved.getHeight() === 1) {
                    widthOrHeight = "height";
                }
                if (widthOrHeight === "width") {
                    let randomHeight = Gallery.getRndInteger(1, blockRemoved.getHeight());
                    widthTemp = blockRemoved.getWidth();
                    heightTemp = blockRemoved.getHeight() - randomHeight;
                    if (heightTemp === 0) {
                        console.log("):")
                    }
                    for (let i = 0; i < partitionsArray.length; i++) {
                        let x1 = partitionsArray[i][0];
                        let y1 = partitionsArray[i][1];
                        if (x1 === widthTemp && y1 === randomHeight) {
                            canPartition1 = false;
                        }
                        if (x1 === widthTemp && y1 === heightTemp) {
                            canPartition2 = false;
                        }
                    }
                    // FIX PARTITION LOGIC MAKE A SEPARATE VARIABLE FOR CAN PARTITION W AND H.
                    block1 = new GridObject(widthTemp, randomHeight, canPartition1);
                    block2 = new GridObject(widthTemp, heightTemp, canPartition2);
                }
                else if (widthOrHeight === "height") {
                    let randomWidth = Gallery.getRndInteger(1, blockRemoved.getWidth());
                    widthTemp = blockRemoved.getWidth() - randomWidth;
                    heightTemp = blockRemoved.getHeight();
                    for (let i = 0; i < partitionsArray.length; i++) {
                        if (partitionsArray[i][0] === randomWidth && partitionsArray[i][1] === heightTemp) {
                            canPartition1 = false;
                        }
                        if (partitionsArray[i][0] === widthTemp && partitionsArray[i][1] === heightTemp) {
                            canPartition2 = false;
                        }
                    }
                    // FIX PARTITION LOGIC MAKE A SEPARATE VARIABLE FOR CAN PARTITION W AND H.
                    block1 = new GridObject(randomWidth, heightTemp, canPartition1);
                    block2 = new GridObject(widthTemp, heightTemp, canPartition2);
                }
                if (canPartition1 || canPartition2) {
                    numPartionableBlocks += 1;
                }
                if (!canPartition1 || !canPartition2) {
                    numPartionableBlocks -= 1;
                }
                //Insert item 2 then item 1
                grid.splice(index, 0, block2);
                grid.splice(index, 0, block1);
                partitions += 1;
            }
        }
        return grid;
    }

    render() {

        return (
            <section className="Gallery">
                {this.state.gridItems !== null && this.state.gridItems}
            </section>
        );


    }
}

export default Gallery;
