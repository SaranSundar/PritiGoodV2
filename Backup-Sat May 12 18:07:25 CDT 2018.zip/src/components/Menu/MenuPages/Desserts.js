import React, {Component} from 'react';

class Desserts extends Component {
    render() {
        return (
            <div>
                <h1>Desserts</h1>
            </div>
        );
    }
}

export default Desserts;
