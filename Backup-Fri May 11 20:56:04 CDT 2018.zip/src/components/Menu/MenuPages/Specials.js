import React, {Component} from 'react';

class Specials extends Component {
    render() {
        return (
            <div>Specials</div>
        );
    }
}

export default Specials;
